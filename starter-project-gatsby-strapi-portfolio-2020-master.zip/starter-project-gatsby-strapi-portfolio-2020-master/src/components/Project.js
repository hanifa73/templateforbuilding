import React from "react"
import PropTypes from "prop-types"
import Image from "gatsby-image"
import { FaGithubSquare, FaShareSquare } from "react-icons/fa"
const Project = () => {
  return <h2>project copmonent</h2>
}

Project.propTypes = {}

export default Project
