import React from "react"
import Title from "./Title"
import Project from "./Project"
import { Link } from "gatsby"
const Projects = () => {
  return <h2>projects list</h2>
}

export default Projects
