import React from "react"
import Title from "./Title"
import services from "../constants/services"
const Services = () => {
  return <h2>services component</h2>
}

export default Services
