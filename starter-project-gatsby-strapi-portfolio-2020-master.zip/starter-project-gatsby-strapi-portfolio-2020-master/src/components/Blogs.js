import React from "react"
import Title from "./Title"
import Blog from "./Blog"
import { Link } from "gatsby"
export const Blogs = () => {
  return <h2>blog list section</h2>
}
export default Blogs
