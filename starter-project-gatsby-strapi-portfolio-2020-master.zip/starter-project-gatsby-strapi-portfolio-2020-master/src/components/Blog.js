import React from "react"
import PropTypes from "prop-types"
import Image from "gatsby-image"
import { Link } from "gatsby"
const Blog = () => {
  return <h2>blog component</h2>
}

Blog.propTypes = {}

export default Blog
