import React from "react"
import Links from "../constants/links"
import SocialLinks from "../constants/socialLinks"
import { FaTimes } from "react-icons/fa"
const Sidebar = () => {
  return <h2>sidebar component</h2>
}

export default Sidebar
