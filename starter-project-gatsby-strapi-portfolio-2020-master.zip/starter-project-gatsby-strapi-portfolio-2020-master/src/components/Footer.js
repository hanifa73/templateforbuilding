import React from "react"
import SocialLinks from "../constants/socialLinks"
const Footer = () => {
  return <h2>footer component</h2>
}

export default Footer
