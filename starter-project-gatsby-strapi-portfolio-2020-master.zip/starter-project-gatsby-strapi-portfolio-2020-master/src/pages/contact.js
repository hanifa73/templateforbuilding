import React from "react"
import Layout from "../components/Layout"

const contact = () => {
  return <h2>contact page</h2>
}

export default contact
